import React, { useState, useRef, useEffect } from 'react';
import './App.css';

const API_URL = 'http://localhost:5000/api';

function App() {
  const [messages, setMessages] = useState([]);
  const [input, setInput] = useState('');
  const [loading, setLoading] = useState(false);
  const [models, setModels] = useState([]);
  const [selectedModel, setSelectedModel] = useState('openrouter/free');
  const messagesEndRef = useRef(null);
  const [uploading, setUploading] = useState(false);
  const fileInputRef = useRef(null);

  // Chat History States
  const [chatHistory, setChatHistory] = useState([]);
  const [currentChatId, setCurrentChatId] = useState(null);
  const [isSidebarOpen, setIsSidebarOpen] = useState(true);

  // Load models
  useEffect(() => {
    fetch(`${API_URL}/models`)
      .then(res => res.json())
      .then(data => setModels(data.models))
      .catch(err => console.error('Error:', err));
  }, []);

  // Load chat history from localStorage
  useEffect(() => {
    const saved = localStorage.getItem('chatHistoryList');
    if (saved) {
      setChatHistory(JSON.parse(saved));
    }
    const savedMessages = localStorage.getItem('chatMessages');
    if (savedMessages) {
      setMessages(JSON.parse(savedMessages));
    }
  }, []);

  // Save messages to localStorage
  useEffect(() => {
    if (messages.length > 0) {
      localStorage.setItem('chatMessages', JSON.stringify(messages));
    }
  }, [messages]);

  // Save chat history list to localStorage
  useEffect(() => {
    localStorage.setItem('chatHistoryList', JSON.stringify(chatHistory));
  }, [chatHistory]);

  // Auto-scroll
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  // ============================================
  // CREATE NEW CHAT
  // ============================================
  const createNewChat = () => {
    if (messages.length > 0) {
      const firstMessage = messages.find(m => m.role === 'user');
      const title = firstMessage ? firstMessage.content.substring(0, 30) + (firstMessage.content.length > 30 ? '...' : '') : 'New Chat';
      
      const newChat = {
        id: Date.now(),
        title: title,
        messages: messages,
        date: new Date().toISOString(),
      };
      setChatHistory(prev => [newChat, ...prev]);
    }
    setMessages([]);
    localStorage.removeItem('chatMessages');
    setCurrentChatId(null);
  };

  // ============================================
  // LOAD A CHAT
  // ============================================
  const loadChat = (chatId) => {
    const chat = chatHistory.find(c => c.id === chatId);
    if (chat) {
      setMessages(chat.messages);
      setCurrentChatId(chatId);
      localStorage.setItem('chatMessages', JSON.stringify(chat.messages));
    }
  };

  // ============================================
  // DELETE A CHAT
  // ============================================
  const deleteChat = (chatId) => {
    if (window.confirm('Delete this chat?')) {
      setChatHistory(prev => prev.filter(c => c.id !== chatId));
      if (currentChatId === chatId) {
        setMessages([]);
        localStorage.removeItem('chatMessages');
        setCurrentChatId(null);
      }
    }
  };

  // ============================================
  // CLEAR CHAT
  // ============================================
  const clearChat = () => {
    if (window.confirm('Are you sure you want to clear all messages?')) {
      setMessages([]);
      localStorage.removeItem('chatMessages');
      setCurrentChatId(null);
    }
  };

  // ============================================
  // SEND MESSAGE
  // ============================================
  const sendMessage = async () => {
    if (!input.trim() || loading) return;

    const userMessage = { role: 'user', content: input };
    setMessages(prev => [...prev, userMessage]);
    setInput('');
    setLoading(true);

    try {
      const response = await fetch(`${API_URL}/chat`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          messages: [...messages, userMessage],
          model: selectedModel,
        }),
      });

      const data = await response.json();
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: data.reply,
      }]);
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: '❌ Error: Unable to get response',
      }]);
    } finally {
      setLoading(false);
    }
  };

  // ============================================
  // FILE UPLOAD
  // ============================================
  const handleFileUpload = async (e) => {
    const file = e.target.files[0];
    if (!file) return;

    setUploading(true);
    const formData = new FormData();
    formData.append('file', file);

    setMessages(prev => [...prev, {
      role: 'user',
      content: `📎 ${file.name}`
    }]);

    try {
      const response = await fetch(`${API_URL}/upload`, {
        method: 'POST',
        body: formData,
      });

      const data = await response.json();
      if (data.success) {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: data.reply,
        }]);
      } else {
        setMessages(prev => [...prev, {
          role: 'assistant',
          content: '❌ Error: ' + data.error,
        }]);
      }
    } catch (error) {
      setMessages(prev => [...prev, {
        role: 'assistant',
        content: '❌ Error uploading file',
      }]);
    } finally {
      setUploading(false);
      e.target.value = '';
    }
  };

  return (
    <div className="app-with-sidebar">
      {/* SIDEBAR TOGGLE BUTTON - SIDEBAR KE BAHAR */}
      <button
        className="sidebar-toggle-btn"
        onClick={() => setIsSidebarOpen(!isSidebarOpen)}
        style={{
          position: 'fixed',
          top: '15px',
          left: isSidebarOpen ? '290px' : '10px',
          zIndex: 999,
          background: '#2c2c2c',
          border: 'none',
          color: 'white',
          fontSize: '22px',
          cursor: 'pointer',
          padding: '8px 12px',
          borderRadius: '8px',
          transition: 'all 0.3s ease',
          boxShadow: '0 2px 10px rgba(0,0,0,0.3)',
        }}
        onMouseEnter={(e) => e.currentTarget.style.background = '#444'}
        onMouseLeave={(e) => e.currentTarget.style.background = '#2c2c2c'}
      >
        {isSidebarOpen ? '◀' : '▶'}
      </button>

      {/* SIDEBAR */}
      <div className={`sidebar ${isSidebarOpen ? 'open' : 'closed'}`}>
        <div className="sidebar-header">
          <button className="new-chat-btn" onClick={createNewChat}>
            ✨ New Chat
          </button>
        </div>
        
        <div className="chat-list">
          {chatHistory.length === 0 ? (
            <div className="empty-chats">
              <p>No chats yet</p>
              <p style={{ fontSize: '12px', color: '#888' }}>Start a new conversation</p>
            </div>
          ) : (
            chatHistory.map(chat => (
              <div
                key={chat.id}
                className={`chat-item ${currentChatId === chat.id ? 'active' : ''}`}
                onClick={() => loadChat(chat.id)}
              >
                <div className="chat-item-content">
                  <span className="chat-title">{chat.title}</span>
                  <span className="chat-date">{new Date(chat.date).toLocaleDateString()}</span>
                </div>
                <button
                  className="delete-chat-btn"
                  onClick={(e) => {
                    e.stopPropagation();
                    deleteChat(chat.id);
                  }}
                >
                  ✕
                </button>
              </div>
            ))
          )}
        </div>
      </div>

      {/* MAIN CHAT AREA */}
      <div className="main-chat-area" style={{ marginLeft: isSidebarOpen ? '0px' : '0px' }}>
        {/* HEADER */}
        <header className="chat-header">
          <div className="header-content">
            <div className="logo">👑 Prince AI</div>
            <h1></h1>

            {/* CLEAR CHAT BUTTON */}
            <button
              onClick={clearChat}
              style={{
                background: 'rgba(255, 255, 255, 0.15)',
                border: 'none',
                color: 'white',
                padding: '6px 14px',
                borderRadius: '20px',
                cursor: 'pointer',
                fontSize: '14px',
                transition: 'all 0.3s ease',
              }}
              onMouseEnter={(e) => e.currentTarget.style.background = 'rgba(255, 0, 0, 0.4)'}
              onMouseLeave={(e) => e.currentTarget.style.background = 'rgba(255, 255, 255, 0.15)'}
            >
              🗑️ Clear Chat
            </button>

            <div className="model-selector">
              {models.map(model => (
                <button
                  key={model.id}
                  className={`model-btn ${selectedModel === model.id ? 'active' : ''}`}
                  onClick={() => setSelectedModel(model.id)}
                >
                  {model.name}
                </button>
              ))}
            </div>
          </div>
        </header>

        {/* CHAT MESSAGES */}
        <div className="chat-container">
          {messages.length === 0 ? (
            <div className="welcome-screen">
              <div className="welcome-icon">🚀</div>
              <h2>Welcome to Prince AI <br /> The time is AI now</h2>
              <p>Select a model and start explore of AI Era!</p>
            </div>
          ) : (
            messages.map((msg, index) => (
              <div
                key={index}
                className={`message ${msg.role === 'user' ? 'user' : 'assistant'}`}
              >
                <div className="avatar">
                  {msg.role === 'user' ? '👤' : '🤖'}
                </div>
                <div className="message-content">
                  <div className="message-text">{msg.content}</div>
                </div>
              </div>
            ))
          )}
          {loading && (
            <div className="message assistant">
              <div className="avatar">🤖</div>
              <div className="message-content">
                <div className="typing-indicator">
                  <span></span><span></span><span></span>
                </div>
              </div>
            </div>
          )}
          {uploading && (
            <div className="message assistant">
              <div className="avatar">📤</div>
              <div className="message-content">
                <div className="message-text">Uploading file... Please wait ⏳</div>
              </div>
            </div>
          )}
          <div ref={messagesEndRef} />
        </div>

        {/* INPUT AREA */}
        <div className="input-container">
          <div className="input-wrapper">
            <input
              type="text"
              value={input}
              onChange={(e) => setInput(e.target.value)}
              onKeyPress={(e) => e.key === 'Enter' && sendMessage()}
              placeholder="Type your message..."
              disabled={loading || uploading}
            />

            <label className="upload-btn" style={{ cursor: 'pointer', padding: '8px 12px', fontSize: '20px' }}>
              📎
              <input
                type="file"
                ref={fileInputRef}
                onChange={handleFileUpload}
                style={{ display: 'none' }}
                accept=".pdf,.docx,.txt,image/*"
                disabled={loading || uploading}
              />
            </label>

            <button
              onClick={sendMessage}
              disabled={!input.trim() || loading || uploading}
              className="send-btn"
            >
              {loading ? '⏳' : '➤'}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;